ConvertFrom-StringData @'
# English strings
CannotFindSpecifiedList = Cannot find specific list: Placeholder01.
CannotFindSpecifiedItem = List item does not exist.
CannotFindSpecifiedAttachment = Placeholder01 does not exit.
AttachmentFeatureDisabled = The attachments feature is currently disabled for this list.
AddAttacment = Adding attachment: Placeholder01.
CannotAddEmptyFile = Cannot add empty file: Placeholder01.
CannotFindAttachments = Cannot find any attachment for this list item.
RecycleItem = Moving Placeholder01 to Recycle Bin.
RemoveItem = Removing Placeholder01.
CannotFindspecificAttachments = Cannot find specific attachments which match this pattern: Placeholder01.
'@