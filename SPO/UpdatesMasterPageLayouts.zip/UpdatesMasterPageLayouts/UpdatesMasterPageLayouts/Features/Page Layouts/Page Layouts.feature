﻿<?xml version="1.0" encoding="utf-8"?>
<feature xmlns:dm0="http://schemas.microsoft.com/VisualStudio/2008/DslTools/Core" dslVersion="1.0.0.0" Id="8d378c4b-094c-4b3f-bccc-8a6e1316a1fa" featureId="8d378c4b-094c-4b3f-bccc-8a6e1316a1fa" imageUrl="" receiverAssembly="$SharePoint.Project.AssemblyFullName$" receiverClass="$SharePoint.Type.6229ded1-3102-4f2f-9923-ee07a3139d6b.FullName$" scope="Site" solutionId="00000000-0000-0000-0000-000000000000" title="Updates MasterPages PageLayouts" version="" deploymentPath="$SharePoint.Project.FileNameWithoutExtension$_$SharePoint.Feature.FileNameWithoutExtension$" xmlns="http://schemas.microsoft.com/VisualStudio/2008/SharePointTools/FeatureModel">
  <projectItems>
    <projectItemReference itemId="0a31b12a-8845-4972-966a-922aead9228d" />
    <projectItemReference itemId="f9cf827d-71ea-4dee-bbfb-94bfa95b3c01" />
  </projectItems>
</feature>