$mmsApplication = Get-SPServiceApplication | ? {$_.TypeName -eq "Managed Metadata Service"}
$mmsProxy = Get-SPServiceApplicationProxy | ? {$_.TypeName -eq "Managed Metadata Service Connection"}
Export-SPMetadataWebServicePartitionData $mmsApplication.Id -ServiceProxy $mmsProxy -Path "C:\ExportedMetadata.cab"
