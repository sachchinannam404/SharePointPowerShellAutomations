﻿$ver = $host | select version 
if($Ver.version.major -gt 1) {$Host.Runspace.ThreadOptions = "ReuseThread"} 
if(!(Get-PSSnapin Microsoft.SharePoint.PowerShell -ea 0)) 
{ 
Write-Progress -Activity "Loading Modules" -Status "Loading Microsoft.SharePoint.PowerShell" 
Add-PSSnapin Microsoft.SharePoint.PowerShell 
} 
 

function ImportTermSet([string]$siteUrl,[string] $termsetname, [string]$filepath, [string]$groupName, [bool]$usedForNavigation)
{
     ##Site URL
     $site = Get-SPSite $siteUrl

     ##CSV file 
     $file = get-item $filepath
     $filename = $file.FullName

    
    $session = Get-SPTaxonomySession -Site $site.Url
    write-host $site.Url
    	
    $store = $session.DefaultKeywordsTermStore

    #### Checking the Group name, if not present and getting the Site collection group
    if($groupName -eq ""){
      $group = $store.GetSiteCollectionGroup($site)
    }
    else{
      $group = $store.Groups[$groupName]
    }

    if ($group -eq $null)
    {
        write-host "Group not found" -ForegroundColor Red
        return
    }
    ##Getting the Termset
    $termset = $group.TermSets[$termsetname]

    if ($termset -eq $null)
    {
        ##Getting Import manager for the Term Store
        $manager = $store.GetImportmanager()
        $reader = new-object System.IO.StreamReader($filename)
    
        $alltermsadded = $false
        $errormessage = ""
    
        write-host "Importing $filename"
        $manager.ImportTermSet($group, $reader, [ref] $alltermsadded, [ref] $errormessage)
    
        $reader.Dispose()
         
	    $termset = $group.TermSets[$termsetname]
        ##Checking if Site Navigation is enabled for the Term store
        ##One can add more custiom properties below depending upon the need
	    if ($usedForNavigation -eq $true)
	    {
		    $termset.SetCustomProperty("_Sys_Nav_IsNavigationTermSet", "True")
		    $termset.SetCustomProperty("_Sys_Nav_AttachedWeb_SiteId", $site.ID.ToString())
		    $termset.SetCustomProperty("_Sys_Nav_AttachedWeb_WebId", $site.RootWeb.ID.ToString())    
		    $termset.SetCustomProperty("_Sys_Nav_AttachedWeb_OriginalUrl", $site.RootWeb.Url)
	    }
   
        if ([string]::IsNullOrEmpty($errormessage) -eq $false)
        {
            write-host $errormessage
        }
    }    
    
	$store.CommitAll()
	$site.Dispose()

}


##For example : Use the following command to import Languages CSV to Default Site collection group of the site 
##ImportTermSet "http://www.contoso.com" "Languages" ".\ImportTermSets\Languages.csv" "" $false







