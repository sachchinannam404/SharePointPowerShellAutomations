﻿<#
.SYNOPSIS
   Get-SPOAllWebs
.DESCRIPTION
   Script to get ALL webs in SharePoint Online sitecollection. Not just the root and one sub level below.
   In order to use this script you need latest SharePoint Server 2013 Client Components SDK installed ! It can be downloaded from here: http://www.microsoft.com/en-us/download/details.aspx?id=35585
   
   The output objects from this script are Microsoft.SharePoint.Client.Web (Webs). This is why in order to receive meaningful information in Powershell you will need proper formatting file loaded or pipe the script to Format-Table -Property Title,Url,Id -AutoSize !
   
   Whit this script is distributed file SharePoint.Client.Format.ps1xml that has display formats for the most SharePoint Online object types.
   
   For more information on displaying CSOM in PowerShell see http://spyankulov.blogspot.com/2014/08/display-csom-objects-in-powershell.html
   For more information on loading powershell format file(ps1xml)in the current session see https://technet.microsoft.com/en-us/library/hh849884.aspx
   
   Author: Ivan Yankulov [ SharePoint Administrator @ BulPros Consulting]
   Contact: http://spyankulov.blogspot.com
   About this script: http://spyankulov.blogspot.com/2015/04/script-to-get-all-webs-in-sharepoint.html
   
.PARAMETER SiteUrl
   The URL of your SharePoint Online site collection
.PARAMETER UserName
   SharePoint Online User with appropriate permissions
.PARAMETER PassWord
   The password for the user in plain text
.EXAMPLE
   .\Get-SPOAllWebs.ps1 -SiteUrl https://contoso-online.sharepoint.com -UserName admin@contoso-online.onmicrosoft.com -PassWord demo!234
   
 Description
 -----------
 This will get all webs under SharePoint Online site collection https://contoso-online.sharepoint.com
.EXAMPLE
   .\Get-SPOAllWebs.ps1 -SiteUrl https://contoso-online.sharepoint.com -UserName admin@contoso-online.onmicrosoft.com -PassWord demo!234 | Format-Table Title,Url,Id -AutoSize
   
 Description
 -----------
 This will get all webs under SharePoint Online site collection https://contoso-online.sharepoint.com and will display the Title,Url,Id as table.Use this in case you do not have loaded the format data for type Microsoft.SharePoint.Client.Web
 .INPUTS
 Syste.String[]
 .OUTPUTS
 Microsoft.SharePoint.Client.Web
 .LINK
http://spyankulov.blogspot.com
http://spyankulov.blogspot.com/2015/04/script-to-get-all-webs-in-sharepoint.html
#>


[CmdletBinding()]
Param(
    [parameter(Mandatory=$true)]
    [string]$SiteUrl,
    [parameter(Mandatory=$true)]
    [string]$UserName,
    [parameter(Mandatory=$true)]
    [string]$PassWord

)
BEGIN{
function Get-SPOSubWebs{
        Param(
        [Microsoft.SharePoint.Client.ClientContext]$Context,
        [Microsoft.SharePoint.Client.Web]$RootWeb
        )


        $Webs = $RootWeb.Webs
        $Context.Load($Webs)
        $Context.ExecuteQuery()

        ForEach ($sWeb in $Webs)
        {
            Write-Output $sWeb
            Get-SPOSubWebs -RootWeb $sWeb -Context $Context
        }
    }
    Add-Type -Path "C:\Program Files\Common Files\microsoft shared\Web Server Extensions\15\ISAPI\Microsoft.SharePoint.Client.dll" | Out-Null
    Add-Type -Path "C:\Program Files\Common Files\microsoft shared\Web Server Extensions\15\ISAPI\Microsoft.SharePoint.Client.Runtime.dll" | Out-Null
}
PROCESS{

    $securePassword = ConvertTo-SecureString $PassWord -AsPlainText -Force
    $spoCred = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($UserName, $securePassword)
    $ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteUrl)
    $ctx.Credentials = $spoCred

    $Web = $ctx.Web
    $ctx.Load($Web)
    $ctx.ExecuteQuery()

    Write-Output $Web

    Get-SPOSubWebs -RootWeb $Web -Context $ctx
}
