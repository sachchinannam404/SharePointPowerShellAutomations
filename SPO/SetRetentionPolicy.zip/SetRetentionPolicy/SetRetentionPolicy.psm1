﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 


Function Set-OSCRetentionPolicy
{
<#
 	.SYNOPSIS
        Set-OSCRetentionPolicy is an advanced function which can be used to set retention policy (Move to Library) on content type at site collection level.
    .DESCRIPTION
        Set-OSCRetentionPolicy is an advanced function which can be used to set retention policy (Move to Library) on content type at site collection level.
    .PARAMETER  SiteUrl
		the specified site URL.
    .PARAMETER  Property
		the action should occur.
    .PARAMETER  Number
		the number of the time.
    .PARAMETER  Period
		the type of time
    .EXAMPLE
        C:\PS> Set-OSCRetentionPolicy -SiteUrl "http://win-lfseeatt8jr/sites/mysite" -Property "Created" -Number 3 -Period "days"
		
		This command shows how to set 'Created 3 days' retention policy to 'http://win-lfseeatt8jr/sites/mysite'.
#>

	[CmdletBinding()]
	Param
	(	
		[Parameter(Mandatory=$true,Position=0)]
		[String]$SiteUrl,
		[Parameter(Mandatory=$true,Position=1)]
		[ValidateSet("Created", "Modified", "Declared Record")]
		[String]$Property,
		[Parameter(Mandatory=$true,Position=2)]
		[Int]$Number,
		[Parameter(Mandatory=$true,Position=3)]
		[ValidateSet("Days", "Months", "Years")]
		[String]$Period
	)
	#Add 'Microsoft.SharePoint.Powershell' Snapin
    if ((Get-PSSnapin | Where-Object {$_.Name -eq 'Microsoft.SharePoint.Powershell'})-eq $null) 
    {
    	Add-PSSnapin "Microsoft.SharePoint.Powershell"
    }
	try
	{
		#Get SharePoint site
	    $site = Get-SPSite -Identity $SiteUrl
	    $web =  $site.OpenWeb(); 
	    $list = $web.Lists["Shared Documents"];
	    $policy = [Microsoft.Office.RecordsManagement.InformationPolicy.ListPolicySettings]($list);
	    $FeatureId = "Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration"
	    if ($policy.ListHasPolicy -eq 0){$policy.UseListPolicy = "true";$policy.Update();}
		#Get the content type 
	    $contentType = $list.ContentTypes["Document"];
		#Get the policy of the content type
	    $newPolicy = [Microsoft.Office.RecordsManagement.InformationPolicy.Policy]::GetPolicy($contentType);
		#Verify if any retention policy exists
	    If($NewPolicy)
	    {
	      	$items =  $NewPolicy.items
	        If(($items | Select Id).Id -eq $FeatureId)
	        {
				#Get the existed retention stage
				$str = ($items | select CustomData).CustomData
				$OldData = $str.Substring($str.IndexOf("<data"), $str.lastIndexOf("</data>")-$str.IndexOf("<data")+7)
				#Combine the new stage with the old stage
			    $CustomData = "<Schedules nextStageId='4'>"+"<Schedule type='Default'>"+"<stages>"+"<data stageId='2' stageDeleted='true'></data>"+"<data stageId='3'>"+"<formula id='Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration.Formula.BuiltIn'>"+
			    "<number>$Number</number>"+"<property>$Property</property>"+"<period>$Period</period>"+"</formula>"+"<action type='action' id='Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration.Action.MoveToRecycleBin' />"+
			    "</data>"+"$OldData"+"</stages>"+"</Schedule>"+"</Schedules>"
	            $newPolicy.Items.delete($FeatureId);
	            $newpolicy.items.add($FeatureId,$CustomData)
	            $newPolicy.Update();
	            Write-Host "Set '$Property $Number $Period' Retention policy to '$SiteUrl' successfully"
	        }
			Else 
			{
				$CustomData = "<Schedules nextStageId='4'>"+"<Schedule type='Default'>"+"<stages>"+"<data stageId='2' stageDeleted='true'></data>"+"<data stageId='3'>"+"<formula id='Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration.Formula.BuiltIn'>"+
	            "<number>$Number</number>"+"<property>$Property</property>"+"<period>$Period</period>"+"</formula>"+"<action type='action' id='Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration.Action.MoveToRecycleBin' />"+
		    	"</data>"+"</stages>"+"</Schedule>"+"</Schedules>"
		        $newpolicy.items.add($FeatureId,$CustomData)
		        $newPolicy.Update();
		        Write-Host "Set '$Property $Number $Period' retention policy to '$SiteUrl' successfully" 
			}
	    }
	    Else 
	    {	
			#Add the  retention policy
			$CustomData = "<Schedules nextStageId='4'>"+"<Schedule type='Default'>"+"<stages>"+"<data stageId='2' stageDeleted='true'></data>"+"<data stageId='3'>"+"<formula id='Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration.Formula.BuiltIn'>"+
	            "<number>$Number</number>"+"<property>$Property</property>"+"<period>$Period</period>"+"</formula>"+"<action type='action' id='Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration.Action.MoveToRecycleBin' />"+
	    	"</data>"+"</stages>"+"</Schedule>"+"</Schedules>"
	        [Microsoft.Office.RecordsManagement.InformationPolicy.Policy]::CreatePolicy($contentType, $null);
	        $newPolicy = [Microsoft.Office.RecordsManagement.InformationPolicy.Policy]::GetPolicy($contentType);
	        $newpolicy.items.add($FeatureId,$CustomData)
	        $newPolicy.Update();
	        Write-Host "Set '$Property $Number $Period' retention policy to '$SiteUrl' successfully" 
	    }
	}
	Catch
	{
		$Err = $Error[0] 
		Write-Host $Err
	}
  
 
}

Function Remove-OSCRetentionPolicy
{	
<#
 	.SYNOPSIS
        Remove-OSCRetentionPolicy is an advanced function which can be used to remove all the retention policy.
    .DESCRIPTION
        Remove-OSCRetentionPolicy is an advanced function which can be used to remove all the retention policy.
    .PARAMETER  SiteUrl
		the specified site URL.
    .EXAMPLE
        C:\PS> Remove-OSCRetentionPolicy -SiteUrl "http://win-lfseeatt8jr/sites/mysite" 
		
		This command shows how to remove the retention policy(Move to Library) that created by Set-OSCRetentionPolicy from 'http://win-lfseeatt8jr/sites/mysite'.
#>

	[CmdletBinding()]
	Param
	(
	[Parameter(Mandatory=$true,Position=0)]
	[String]$SiteUrl
	)
	if ((Get-PSSnapin | Where-Object {$_.Name -eq 'Microsoft.SharePoint.Powershell'})-eq $null) 
    {
    	Add-PSSnapin "Microsoft.SharePoint.Powershell"
    }
	try
	{
		#Get SharePoint site
		$site = Get-SPSite -Identity $SiteUrl
	    $web =  $site.OpenWeb();
	    $list = $web.Lists["Shared Documents"];
	    $FeatureId = "Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration"
	    $contentType = $list.ContentTypes["Document"];
		#Get the retention policy
	    $newPolicy = [Microsoft.Office.RecordsManagement.InformationPolicy.Policy]::GetPolicy($contentType);
	    If($NewPolicy)
	    {
			$items =  $NewPolicy.items
	        If(($items | Select Id).Id -eq $FeatureId)
	        {
				#Delete the policy
				$newPolicy.Items.delete($FeatureId);
	            $newPolicy.Update();
				Write-Host "Delete retention policy from '$SiteUrl' successfully" 
			}
			Else
			{
				Write-Warning "There is no retention policy defined in '$SiteUrl'"
			}
		}
		Else
		{
			Write-Warning "There is no retention policy defined in '$SiteUrl'"
		}
	}
	Catch
	{
		$Err = $Error[0] 
		Write-Host $Err
	}
}


 