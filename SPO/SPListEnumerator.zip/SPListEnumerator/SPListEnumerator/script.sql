--------------------------------------------------------------------------------- 
-- The sample scripts are not supported under any Microsoft standard support 
-- program or service. The sample scripts are provided AS IS without warranty  
-- of any kind. Microsoft further disclaims all implied warranties including,  
-- without limitation, any implied warranties of merchantability or of fitness for 
-- a particular purpose. The entire risk arising out of the use or performance of  
-- the sample scripts and documentation remains with you. In no event shall 
-- Microsoft, its authors, or anyone else involved in the creation, production, or 
-- delivery of the scripts be liable for any damages whatsoever (including, 
-- without limitation, damages for loss of business profits, business interruption, 
-- loss of business information, or other pecuniary loss) arising out of the use 
-- of or inability to use the sample scripts or documentation, even if Microsoft 
-- has been advised of the possibility of such damages 
--------------------------------------------------------------------------------- 


USE AdventureWorks;
GO 
SELECT  
  DB_NAME(database_id) AS Database_Name, 
  name AS Logical_Name, 
  physical_name AS Physical_Name, 
  type_desc AS Type_Description 
FROM sys.master_files WHERE database_id = DB_ID(); 
GO


USE master; 
GO 
ALTER DATABASE AdventureWorks SET online; 
GO


-- After we took the database offline, we could run the following query to 
-- modify its file path information in the system catalog which will be used 
-- the next time the database is started. 
USE master; 
GO 
ALTER DATABASE AdventureWorks  
MODIFY  
FILE (NAME = AdventureWorks_Data,  
  FILENAME = 'C:\AdventureWorks\AdventureWorks_Data.mdf'); 
GO


-- After we moved the database file(s) physically in the file system as well as  
-- changed its path information in the SQL Server, we can bring the database online 
-- via the following query under master database execution context. 
USE master; 
GO 
ALTER DATABASE AdventureWorks SET ONLINE; 
GO


