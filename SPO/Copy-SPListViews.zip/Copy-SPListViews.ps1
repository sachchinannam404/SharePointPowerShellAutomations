﻿    <#
.SYNOPSIS
   Copy-SPListViews
.DESCRIPTION
   Script to copy all public views and current user private views from one SharePoint list/library to another.

   The source and the destination lists can be in the same web or in different site collections/webs.

   Properties that will be copied: Title , View Query, Is Paged, Is Personal View , Row Limit, Is Default View, View Fields, View Type

   If there is a view with same name in the source and destination list it will not be overwritten, a new view with the parameters of the source will be created.

   Tested on: SharePoint 2010, SharePoint 2013, SharePoint 2016 RC

   Author: Ivan Yankulov [ Senior SharePoint Engineer @ bluesource Information Limited ]
   Contact: http://spyankulov.blogspot.com
   About this script: http://spyankulov.blogspot.com/2016/02/copy-list-views-in-sharepoint-online-powershell.html
   
.PARAMETER SourceWebUrl
   The URL of the source web
.PARAMETER DestinationWebUrl
   The URL of the destination web
.PARAMETER SourceListTitle
   The source list Name/Title
.PARAMETER DestinationListTitle
   The destination list Name/Title
.EXAMPLE
   .\Copy-SPListViews.ps1 -SourceWebUrl "https://portal.contoso.com/sites/teamsite/" -DestinationWebUrl "https://portal.contoso.com/hr" -SourceListTitle "Team Documents" -DestinationListTitle "HR Documents"
   
 Description
 -----------
 This will copy the views from the source list "Team Documents" to destination list "HR Documents"

 .INPUTS
 System.String[]
 .OUTPUTS
 .LINK
http://spyankulov.blogspot.com
http://spyankulov.blogspot.com/2016/02/copy-list-views-in-sharepoint-online-powershell.html
#>

	[CmdletBinding()]
    Param(
    [parameter(Mandatory=$true)]
	[string]$SourceWebUrl,
    [parameter(Mandatory=$true)]
	[string]$DestinationWebUrl,
    [parameter(Mandatory=$true)]
	[string]$SourceListTitle,
    [parameter(Mandatory=$true)]
	[string]$DestinationListTitle
    )
BEGIN{
    Add-PSSnapin *SH* -ErrorAction SilentlyContinue
    $sWeb = Get-SPWeb -Identity $SourceWebUrl
    $sourceList = $sWeb.Lists[$SourceListTitle]

	$dWeb = Get-SPWeb -Identity $DestinationWebUrl
    $destinationList = $dWeb.Lists[$DestinationListTitle]

	$sourceViews = $sourceList.Views
	$destinationViews = $destinationList.Views
}
PROCESS{
	ForEach($sourceView in ($sourceViews | Where {$_.Hidden -eq $false})){
		Write-Host "Creating View `"$($sourceView.Title)`"" -ForegroundColor Green
		$title = $sourceView.Title

		$viewFlds = New-Object System.Collections.Specialized.StringCollection
		
		ForEach ($vf in $sourceView.ViewFields){
			$viewFlds.Add($vf.ToString()) | Out-Null
		}
		$vQuery = $sourceView.Query
		$vRowLimit = $sourceView.RowLimit
		$vPaged = $sourceView.Paged
		$vDF = $sourceView.DefaultView
		$vType = $sourceView.Type
		$vPersonal = $sourceView.PersonalView
		
		$destinationList.Views.Add($title,$viewFlds,$vQuery,$vRowLimit,$vPaged,$vDF,$vType,$vPersonal) | Out-Null
		
	}
	$destinationList.Update()
}