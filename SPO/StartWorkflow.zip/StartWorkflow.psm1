﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Start-OSCSPWorkflow
{
	#.EXTERNALHELP Start-OSCSPWorkflow-Help.xml
	
	[CmdletBinding(DefaultParameterSetName="ID")]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$SiteURL,
		[Parameter(Mandatory=$true,Position=2)]
		[string]$ListName,
		[Parameter(Mandatory=$true,Position=3)]
		[string]$WorkflowName,
		[Parameter(Mandatory=$false,Position=4)]
		[int]$MaxConcurrentWorkflowNumber=10,
		[Parameter(Mandatory=$true,Position=5,ParameterSetName="ID")]
		[int[]]$ItemId,
		[Parameter(Mandatory=$true,Position=5,ParameterSetName="CAML")]
		[string]$Query,
		[Parameter(Mandatory=$false,Position=6,ParameterSetName="CAML")]
		[int]$RowLimit=100,
		[Parameter(Mandatory=$false,Position=7,ParameterSetName="CAML")]
		[Microsoft.SharePoint.SPViewScope]$ViewScope="Default"
	)
	Process
	{
		#Use Get-SPWeb to get a Microsoft SharePoint SPWeb object
		Try
		{	
			$spWeb = Get-SPWeb -Identity $SiteURL -ErrorAction Stop -Verbose:$false
		}
		Catch 
		{
			$pscmdlet.ThrowTerminatingError($_)
		}
		
		#Try to get a list item
		$spList = $spWeb.Lists.TryGetList($ListName)
		if ($spList -eq $null) {
			$spWeb.Dispose()
			$errorMsg = $Messages.CannotFindSpecifiedList
			$errorMsg = $errorMsg -f $ListName
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.ThrowTerminatingError($customError)
		}
		
		#Try to get a workflow item
		$spWorkFlow = $spList.WorkflowAssociations.GetAssociationByName($WorkflowName,[System.Globalization.CultureInfo]::CurrentCulture)
		if ($spWorkFlow -eq $null) {
			$spWeb.Dispose()
			$errorMsg = $Messages.CannotFindSpecifiedWorkflow
			$errorMsg = $errorMsg -f $WorkflowName		
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.ThrowTerminatingError($customError)
		}
		
		#Verify workflow type
		#True if the workflow association is a declarative, files-based workflow
		#False if the workflow association is a compiled workflow assembly. 
		if ($spWorkFlow.IsDeclarative) {
			$spListItems = @()
			Switch ($pscmdlet.ParameterSetName) {
				"ID" {
					foreach ($listItemID in $ItemID) {
						#Try to get list item by ID
						Try
						{
							$spListItem = $spList.GetItemById($listItemID)
							$spListItems += $spListItem
						}
						Catch
						{
							$errorMsg = $Messages.CannotFindSpecifiedItem
							$errorMsg = $errorMsg -f $listItemID
							$customError = New-OSCPSCustomErrorRecord `
							-ExceptionString $errorMsg `
							-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
							$pscmdlet.WriteError($customError)				
						}
					}
				}
				"CAML" {
					$spQuery = New-Object Microsoft.SharePoint.SPQuery
					$spQuery.Query = $Query
					$spQuery.RowLimit = $RowLimit
					$spQuery.ViewAttributes = "Scope='$ViewScope'"
					$spListItems = $spList.GetItems($spQuery)
				}
			}
			#If list items exist, start the workflow.
			if ($spListItems.Count -le $MaxConcurrentWorkflowNumber) {
				foreach ($spListItem in $spListItems) {
					$verboseMsg = $Messages.StartingWorkflow
					$verboseMsg = $verboseMsg -f $WorkflowName,"$($spListItem.Title)(ID:$($spListItem.ID))"
					$pscmdlet.WriteVerbose($verboseMsg)
					Try
					{
						$spWFInstance = $spWeb.Site.WorkflowManager.StartWorkflow($spListItem,$spWorkFlow,$spWorkFlow.AssociationData,$true)
					}
					Catch
					{
						$pscmdlet.WriteError($_)			
					}
				}
			} else {
				$warningMsg = $Messages.MaxConcurrentWFNumber
				$pscmdlet.WriteWarning($warningMsg)				
			}
		} else {
			$warningMsg = $Messages.CannotRunVSWorkflow
			$pscmdlet.WriteWarning($warningMsg)
		}
		$spWeb.Dispose()
	}
}

Export-ModuleMember -Function "Start-OSCSPWorkflow"