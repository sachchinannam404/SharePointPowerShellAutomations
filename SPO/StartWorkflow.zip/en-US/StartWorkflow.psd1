﻿ConvertFrom-StringData @'
# English strings
CannotFindSpecifiedList = Cannot find specified list: {0}.
CannotFindSpecifiedWorkflow = Cannot find specified workflow: {0}.
CannotFindSpecifiedItem = Cannot find the specified item.
StartingWorkflow = Starting workflow {0} on list item {1}.
CannotRunVSWorkflow = You cannot use this script to start a workflow that created by Visual Studio.
MaxConcurrentWFNumber = Please adjust the maximum number of workflows that can be run simultaneoulsy after verifying the performance and capacity of your server farm. The default value is 10.
'@