﻿<#
.SYNOPSIS
The script shows the size of all attachments from a specific list.

.DESCRIPTION
You can get the size of all attachments from a specific list. 
You should give the site url and the list title where you need to know the storage usage.

.EXAMPLE
Get-SizeOfAttachments.ps1 -url "http://site" -title "title" 
#>

#NAME: Get-SizeOfAttachments.ps1
#AUTHOR: Tibor Revesz
#DATE: 18/11/2013

param (
    [Parameter(Mandatory=$true)]
    [string]$url = "",
    [Parameter(Mandatory=$true)]
    [string]$title = ""
    )

If((Get-PSSnapin Microsoft.SharePoint.PowerShell –EA SilentlyContinue) –eq
$null){Add-PSSnapin Microsoft.SharePoint.PowerShell}

$size = 0
$web = Get-SPWeb $url 
$web | select -ExpandProperty lists | 
Where {$_.Title -eq "$title"} | 
Select -ExpandProperty Items | 
ForEach-Object {$web.getfolder($_.Attachments.UrlPrefix)} | 
Select -ExpandProperty files | 
ForEach-Object {$size += $_.length}
"Size of attachments: {0:N2} MB" -f ($size/1MB)